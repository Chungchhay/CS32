/**
 *  Program Name: mazestack.cpp
 *  Written By:   Chungchhay Kuoch
 *  Date:         2017 02 04
 */

#include <stack>
#include <iostream>
using namespace std;

class Coord
{
public:
  Coord(int rr, int cc) : m_r(rr), m_c(cc) {}
  
  int r() const
  {
    return m_r;
  }
  
  int c() const
  {
    return m_c;
  }
  
private:
  int m_r;
  int m_c;
};

bool pathExists(string maze[], int nRows, int nCols, int sr, int sc, int er, int ec)
{
  if (sr >= nRows || sc >= nCols || er >= nRows || ec >= nCols)
  {
    cout << "Out of bound" << endl;
    return false;
  }
  
  for (int i = 0; i < nRows; i++)
  {
    for (int j = 0; j < nCols; j++)
    {
      if (maze[i][j] != '.' && maze[i][j] != 'X')
      {
        cout << "Maze must contain either '.' or 'X'" << endl;
        return false;
      }
    }
  }
  
  for (int i = 0; i < nRows; i++)
  {
    if (maze[i][0] != 'X' || maze[i][nCols - 1] != 'X')
    {
      cout << "Left and Right columns must contain 'X'" << endl;
      return false;
    }
  }
  
  for (int i = 0; i < nCols; i++)
  {
    if (maze[0][i] != 'X' || maze[nRows - 1][i] != 'X')
    {
      cout << "Top and Bottom columns must contain 'X'" << endl;
      return false;
    }
  }
  
  stack<Coord> coordStack;
  coordStack.push(Coord(sr, sc));
  maze[sr][sc] = 'V'; // V stands for Visited
  
  while (!coordStack.empty())
  {
    Coord temp = coordStack.top(); // store the top coordinate of the stack
    
    coordStack.pop();
    
    if (temp.r() == er && temp.c() == ec)
      return true;
    
    if (maze[temp.r() - 1][temp.c()] == '.')
    {
      coordStack.push(Coord(temp.r() - 1, temp.c()));
      maze[temp.r() - 1][temp.c()] = 'V';
    }
    
    if (maze[temp.r()][temp.c() + 1] == '.')
    {
      coordStack.push(Coord(temp.r(), temp.c() + 1));
      maze[temp.r()][temp.c() + 1] = 'V';
    }
    
    if (maze[temp.r() + 1][temp.c()] == '.')
    {
      coordStack.push(Coord(temp.r() + 1, temp.c()));
      maze[temp.r() + 1][temp.c()] = 'V';
    }
    
    if (maze[temp.r()][temp.c() - 1] == '.')
    {
      coordStack.push(Coord(temp.r(), temp.c() - 1));
      maze[temp.r()][temp.c() - 1] = 'V';
    }
  }
  
  return false;
}

int main()
{
  string maze[10] = {
    "XXXXXXXXXX",
    "X........X",
    "XX.X.XXXXX",
    "X..X.X...X",
    "X..X...X.X",
    "XXXX.XXX.X",
    "X.X....XXX",
    "X..XX.XX.X",
    "X...X....X",
    "XXXXXXXXXX"
  };
  
  if (pathExists(maze, 10,10, 6,4, 1,1))
    cout << "Solvable!" << endl;
  else
    cout << "Out of luck!" << endl;
}

