/**
 *  Program Name: eval.cpp
 *  Written By:   Chungchhay Kuoch
 *  Date:         2017 02 04
 */

#include <iostream>
#include <stack>
#include <cstring>
#include <cassert>
using namespace std;


void gotOrOperator(stack<bool> &boolStack);
// When got Or operator from postfix, push it to the stack
void gotAndOperator(stack<bool> &boolStack);
// When got And operator from postfix, push it to the stack
void gotNotOperator(stack<bool> &boolStack);
// When got Not operator from postfix, push it to the stack
void pushOperandToStack(stack<bool> &boolStack, const bool values[], char arg);
// When got operand from postfix, push it to the stack
// Above are functions for evaluate postfix expression

// Below are functions for converting infix to postfix
bool isOperand(char arg);
// Check if it is operand or not
void isAnOperator(char arg, int prec1, stack<char> &charStack, string &postfix);
// Check if it is operator or not
void isParenthesis(stack<char> &charStack, string &postfix);
// Check if it is parenthesis or not
string infixToPostFix(const string &infix);
// converting infix to postfix

int evaluate(string infix, const bool values[], string& postfix, bool& result)
{
  //Converting infix to postfix
  postfix = infixToPostFix(infix);
  
  // Check if postfix equals -1 means the infix expression is invalid
  if (postfix == "-1")
    return 1;
  
  // Up to here I know that the user has entered the right infix expression
  // And converted to postfix successfully
  
  stack<bool> boolStack;
 
  // Iterate every character in postfix
  for (int i = 0; i < postfix.length(); i++)
  {
    char temp = postfix[i]; // Store each ch in postfix to temp
    
    if (isOperand(temp))
    {
      // When got a digit, push it to the stack
      pushOperandToStack(boolStack, values, temp);
      continue;
    }
    
    switch (temp)
    {
      case '|':
        gotOrOperator(boolStack);
        break;
      case '!':
        gotNotOperator(boolStack);
        break;
      case '&':
        gotAndOperator(boolStack);
        break;
    }
  }
  
  // Right here, I know that it will have only 1 boolean value in the stack
  result = boolStack.top();
  boolStack.pop();
  return 0;
}

void gotOrOperator(stack<bool> &boolStack)
{
  // When got | operator, pop 2 times
  bool arg1 = boolStack.top();
  boolStack.pop();
  bool arg2 = boolStack.top();
  boolStack.pop();
  
  // Logic expression
  if (arg1 == false && arg2 == false)
    boolStack.push(false);
  else
    boolStack.push(true);
}

void gotAndOperator(stack<bool> &boolStack)
{
  // When got & operator, pop 2 times
  bool x = boolStack.top();
  boolStack.pop();
  bool y = boolStack.top();
  boolStack.pop();
  
  // Logic expression
  if (x == true && y == true)
    boolStack.push(true);
  else
    boolStack.push(false);
}

void gotNotOperator(stack<bool> &boolStack)
{
  // When got ! operator, only pop 1 time
  bool a = boolStack.top();
  
  boolStack.pop();
  
  // Logic expression
  if (a)
    boolStack.push(false);
  else
    boolStack.push(true);
}

void pushOperandToStack(stack<bool> &boolStack, const bool values[], char arg)
{
  // Check which boolean values to push in the stack
  switch (arg) {
    case '0':
      boolStack.push(values[0]);
      break;
    case '1':
      boolStack.push(values[1]);
      break;
    case '2':
      boolStack.push(values[2]);
      break;
    case '3':
      boolStack.push(values[3]);
      break;
    case '4':
      boolStack.push(values[4]);
      break;
    case '5':
      boolStack.push(values[5]);
      break;
    case '6':
      boolStack.push(values[6]);
      break;
    case '7':
      boolStack.push(values[7]);
      break;
    case '8':
      boolStack.push(values[8]);
      break;
    case '9':
      boolStack.push(values[9]);
      break;
  }
}
bool isOperand(char arg) {
  //Check if it is a digit, return true. Otherwise, return false
  return isdigit(arg);
}

void isAnOperator(char arg, int prec1, stack<char> &charStack, string &postfix)
{
  // When getting an operator, I push it if it is empty
  // Otherwise, check to see if the operator(s) in the stack is equal to or has higher
  // precedence than precedence of operator arg or not.
  // If it is higher or equal, I push it to the stack. If it is not,
  // I add it to postfix.
  while (!charStack.empty())
  {
    char temp = charStack.top();
    charStack.pop();
    if (temp == '(')
    {
      charStack.push(temp);
      break;
    }
    else
    {
      int prec2;
      if (temp == '|')
        prec2 = 1;
      else if (temp == '&')
        prec2 = 2;
      else
        prec2 = 3;
      
      if (prec1 >= prec2)
      {
        charStack.push(temp);
        break;
      }
      else
      {
        postfix += temp;
      }
    }
  }
  
  charStack.push(arg);
}

void isParenthesis(stack<char> &charStack, string &postfix)
{
  // When getting ) parenthesis, I pop the stack until I see ( parenthesis, then stop.
  // If I don't see ( parenthesis in the stack, I know that the infix expression
  // must be wrong
  char wrongExpression = ' ';
  
  while (!charStack.empty())
  {
    char temp = charStack.top();
    charStack.pop();
    
    if (temp == '(')
    {
      wrongExpression = '('; // Check if there is no (, the expression must be wrong
      break;
    }
    else
    {
      postfix += temp;
    }
  }
  
  if (wrongExpression != '(')
    postfix = "-1";
  
}

string infixToPostFix(const string &infix)
{
  string postfix;
  stack<char> charStack;
  int count = 0; // count is to check the user enter the right expression or not
  
  // Check every character in the infix expression
  for (int i = 0; i < infix.length(); i++)
  {
    char temp = infix[i];
    // Check if it is a digit, add it to postfix
    if (isOperand(temp))
    {
      // if the user enter 2 digits without any operator,
      // count will be equal to 1, and wrong expression
      if (count != 0)
      {
        postfix = "-1";
        return postfix;
      }
      count = 1;
      postfix += temp;
      continue;
    }
    
    switch (temp)
    {
      case '!':
        // After entering a digit, the user should enter any operator
        // other than NOT operator. Otherwise, wrong expression
        if (count == 1)
        {
          postfix = "-1";
          return postfix;
        }
        isAnOperator(temp, 3, charStack, postfix);
        break;
      case '&':
        // if the user enter operator without any operand,
        // count will be equal to 0, and wrong expression
        if (count != 1)
        {
          postfix = "-1";
          return postfix;
        }
        count = 0;
        isAnOperator(temp, 2, charStack, postfix);
        break;
      case '|':
        // if the user enter operator without any operand,
        // count will be equal to 0, and wrong expression
        if (count != 1)
        {
          postfix = "-1";
          return postfix;
        }
        count = 0;
        isAnOperator(temp, 1, charStack, postfix);
        break;
      case '(':
        if (count == 1)
        {
          postfix = "-1";
          return postfix;
        }
        charStack.push(temp);
        break;
      case ')':
        isParenthesis(charStack, postfix);
        if (postfix == "-1")
          return postfix;
        break;
      case ' ':
        // When getting a space ' ', ignore it
        break;
      default:
        postfix = "-1";
        return postfix;
    }
  }
  
  // Check if the user enters an operator at the end of the string
  // if they put the operator at the end of the string, the expression is wrong
  if (count == 0)
  {
    postfix = "-1";
    return postfix;
  }
  
  // Keep poping the stack until it is empty
  while (!charStack.empty())
  {
    char temp = charStack.top();
    
    if (temp == '(')
    {
      postfix = "-1";
      break;
    }
    charStack.pop();
    postfix += temp;
  }
  
  return postfix;
}


int main() {
  bool ba[10] = {
    //  0      1      2      3      4      5      6      7      8      9
    true,  true,  true,  false, false, false, true,  false, true,  false
  };
  string pf;
  bool answer;
  assert(evaluate("2| 3", ba, pf, answer) == 0  &&  pf == "23|" &&  answer);
  assert(evaluate("8|", ba, pf, answer) == 1);
  assert(evaluate("4 5", ba, pf, answer) == 1);
  assert(evaluate("01", ba, pf, answer) == 1);
  assert(evaluate("()", ba, pf, answer) == 1);
  assert(evaluate("2(9|8)", ba, pf, answer) == 1);
  assert(evaluate("2(&8)", ba, pf, answer) == 1);
  assert(evaluate("(6&(7|7)", ba, pf, answer) == 1);
  assert(evaluate("", ba, pf, answer) == 1);
  assert(evaluate("4  |  !3 & (0&3) ", ba, pf, answer) == 0
         &&  pf == "43!03&&|"  &&  !answer);
  assert(evaluate(" 9  ", ba, pf, answer) == 0  &&  pf == "9"  &&  !answer);
  ba[2] = false;
  ba[9] = true;
  assert(evaluate("((9))", ba, pf, answer) == 0  &&  pf == "9"  &&  answer);
  assert(evaluate("2| 3", ba, pf, answer) == 0  &&  pf == "23|" &&  !answer);
  cout << "Passed all tests" << endl;
  return 0;
}
