//
//  Sequence.cpp
//  Homework1
//
//  Created by chungchhay kuoch on 1/20/17.
//  Copyright © 2017 chungchhay kuoch. All rights reserved.
//

#include "Sequence.h"

//Initialized the objects
Sequence::Sequence()
{
  n = 0;
}

Sequence::Sequence(const Sequence &arg)
{
  n = arg.n;
  for (int i = 0; i < n; i++)
    s[i] = arg.s[i];
}

Sequence &Sequence::operator=(const Sequence &arg)
{
  n = arg.n;
  for (int i = 0; i < n; i++)
    s[i] = arg.s[i];
  
  return *this;
}

Sequence::~Sequence() {
  
}

//Check if the sequence is empty or not
bool Sequence::empty() const
{
  if (n == 0)
    return true;
  
  return false;
}

//return the size of sequence
int Sequence::size() const
{
  return n;
}

//insert a string in the sequence at the position pos
bool Sequence::insert(int pos, const ItemType &value)
{
  if (pos >= 0 && pos <= n && n < DEFAULT_MAX_ITEMS)
  {
    for (int i = n; i > pos; i--)
      s[i] = s[i - 1];
    
    s[pos] = value;
    n++;
    return true;
  }
  
  return false;
}

int Sequence::insert(const ItemType &value)
{
  int p;
  if (size() == DEFAULT_MAX_ITEMS)
    return -1;
  
  for (int i = 0; i < n; i++)
  {
    if (value <= s[i])
    {
      p = i;
      insert(p, value);
      return p;
    }
  }
    
  p = n;
  s[p] = value;
  n++;
  return p;
}

//erase a string at the position pos
bool Sequence::erase(int pos)
{
  if (pos < size() && pos >= 0)
  {
    for (int i = pos + 1; i < n; i++)
      s[i - 1] = s[i];
    
    n--;
    return true;
  }
  
  return false;
}

//remove whatever equal to value
int Sequence::remove(const ItemType &value)
{
  int count = 0;
  for (int i = 0; i < n; i++)
  {
    if (s[i] == value)
    {
      erase(i);
      if (s[i] == value)
        i--;
      
      count++;
    }
  }
  
  return count;
}


bool Sequence::get(int pos, ItemType &value) const
{
  if (pos < n && pos >= 0)
  {
    value = s[pos];
    return true;
  }

  return false;
}


bool Sequence::set(int pos, const ItemType &value)
{
  if (pos < n && pos >= 0)
  {
    s[pos] = value;
    return true;
  }

  return false;
}

int Sequence::find(const ItemType &value) const
{
  int p = n;
  for (int i = 0; i < p; i++)
  {
    if (s[i] == value)
    {
      p = i;
      return p;
    }
  }

  p = -1;
  return p;
}

void Sequence::swap(Sequence &other)
{
  int tempSize = n;
  int tempSize1 = other.n;
  ItemType temp;
  
  (n < other.n) ? n = other.n : other.n = n;
  
  for (int i = 0; i < n; i++)
  {
    temp = s[i];
    s[i] = other.s[i];
    other.s[i] = temp;
  }

  n = tempSize1;
  other.n = tempSize;
}





