//
//  newSequence.cpp
//  Homework1
//
//  Created by chungchhay kuoch on 1/22/17.
//  Copyright © 2017 chungchhay kuoch. All rights reserved.
//
/*
#include "newSequence.h"
#include <iostream>
#include <cstdlib>
using namespace std;

//Initialized the objects
Sequence::Sequence()
{
  n = DEFAULT_MAX_ITEMS;
  currItems = 0;
  s = new ItemType[n];
}

Sequence::Sequence(int arg)
{
  if (arg < 0)
  {
    cout << "Invalid size" << endl;
    exit(1);
  }
  
  n = arg;
  currItems = 0;
  s = new ItemType[n];
}

Sequence::Sequence(const Sequence &arg)
{
  n = arg.n;
  currItems = arg.currItems;
  s = new ItemType[n];
  
  for (int i = 0; i < arg.currItems; i++)
    s[i] = arg.s[i];
}

Sequence &Sequence::operator=(const Sequence &arg)
{
  if (&arg == this)
    return *this;
  
  Sequence temp(arg);
  this->swap(temp);
  
  return *this;
}

Sequence::~Sequence() {
  delete [] s;
}

//Check if the sequence is empty or not
bool Sequence::empty() const
{
  if (currItems == 0)
    return true;
  
  return false;
}

//return the size of sequence
int Sequence::size() const
{
  return currItems;
}

//insert a string in the sequence at the position pos
bool Sequence::insert(int pos, const ItemType &value)
{
  if (pos >= 0 && pos <= currItems && currItems < n)
  {
    for (int i = currItems; i > pos; i--)
      s[i] = s[i - 1];
    
    currItems++;
    s[pos] = value;
    return true;
  }
  
  return false;
}

int Sequence::insert(const ItemType &value)
{
  int p;
  if (currItems == n)
    return -1;
  else
  {
    for (int i = 0; i < currItems; i++)
    {
      if (value <= s[i])
      {
        p = i;
        for (int j = currItems; j > p; j--)
          s[j] = s[j-1];
        
        s[p] = value;
        currItems++;
        return p;
      }
    }
    
    p = currItems;
    s[p] = value;
    currItems++;
    return p;
  }
}

//erase a string at the position pos
bool Sequence::erase(int pos)
{
  if (pos < currItems && pos >= 0)
  {
    for (int i = pos; i < currItems; i++)
      s[i] = s[i+1];
    
    currItems--;
    return true;
  }
  
  return false;
}

//remove whatever equal to value
int Sequence::remove(const ItemType &value)
{
  int count = 0;
  
  for (int i = 0; i < currItems; i++)
  {
    if (s[i] == value)
    {
      erase(i);
      if (s[i] == value)
        i--;
      
      count++;
    }
  }
  return count;
}

bool Sequence::get(int pos, ItemType &value) const
{
  if (pos < currItems && pos >= 0)
  {
    value = s[pos];
    return true;
  }
  
  return false;
}


bool Sequence::set(int pos, const ItemType &value)
{
  if (pos < currItems && pos >= 0)
  {
    s[pos] = value;
    return true;
  }
  
  return false;
}

int Sequence::find(const ItemType &value) const
{
  int p = currItems;
  for (int i = 0; i < p; i++)
  {
    if (s[i] == value)
    {
      p = i;
      return p;
    }
  }
  
  p = -1;
  return p;
}

void Sequence::swap(Sequence &other)
{
  ItemType *temp = s;
  s = other.s;
  other.s = temp;
  
  int temp1 = n;
  n = other.n;
  other.n = temp1;
  
  int temp2 = currItems;
  currItems = other.currItems;
  other.currItems = temp2;
}
 */
