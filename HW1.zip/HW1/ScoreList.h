//
//  ScoreList.hpp
//  Homework1
//
//  Created by chungchhay kuoch on 1/22/17.
//  Copyright © 2017 chungchhay kuoch. All rights reserved.
//

#ifndef ScoreList_h
#define ScoreList_h
#include "Sequence.h"
#include <limits>

const ItemType NO_SCORE = std::numeric_limits<ItemType>::max();

class ScoreList
{
public:
  ScoreList();
  bool add(ItemType score);
  bool remove(ItemType score);
  int size() const;
  ItemType minimum() const;
  ItemType maximum() const;
  
private:
  Sequence listOfScores;
};
#endif /* ScoreList_hpp */
