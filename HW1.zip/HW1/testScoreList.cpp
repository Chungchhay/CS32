//
//  testScoreList.cpp
//  Homework1
//
//  Created by chungchhay kuoch on 1/22/17.
//  Copyright © 2017 chungchhay kuoch. All rights reserved.
//

/*#include <iostream>
#include "ScoreList.h"
using namespace std;

int main()
{
  ScoreList s;
  s.add(1);
  s.add(50);
  s.add(25);
  s.add(23);
  s.add(18);
  cout << "hi" << s.maximum() << endl;
  cout << "hello" << s.size() << endl;
  s.print();
}
*/