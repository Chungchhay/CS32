//
//  testnewSequence.cpp
//  Homework1
//
//  Created by chungchhay kuoch on 1/22/17.
//  Copyright © 2017 chungchhay kuoch. All rights reserved.
//

