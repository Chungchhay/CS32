//
//  Sequence.hpp
//  Homework1
//
//  Created by chungchhay kuoch on 1/20/17.
//  Copyright © 2017 chungchhay kuoch. All rights reserved.
//

#ifndef Sequence_h
#define Sequence_h
//typedef is easy for programmers to change its type only one time by changing datatype here
typedef unsigned long ItemType;

const int DEFAULT_MAX_ITEMS = 200;

class Sequence
{
public:
  Sequence();
  Sequence(const Sequence &arg);
  Sequence &operator=(const Sequence &arg);
  ~Sequence();
  
  bool empty() const;
  int size() const;
  
  bool insert(int pos, const ItemType &value);
  int insert(const ItemType &value);
  bool erase(int pos);
  int remove(const ItemType &value);
  bool get(int pos, ItemType &value) const;
  bool set(int pos, const ItemType &value);
  int find(const ItemType &value) const;
  void swap(Sequence &other);
  
private:
  int n; //Size of the sequence
  ItemType s[DEFAULT_MAX_ITEMS]; //sequence of strings
};

#endif
