//
//  ScoreList.cpp
//  Homework1
//
//  Created by chungchhay kuoch on 1/22/17.
//  Copyright © 2017 chungchhay kuoch. All rights reserved.
//

#include "ScoreList.h"
#include "Sequence.h"

ScoreList::ScoreList()
{

}

bool ScoreList::add(ItemType score)
{
  if (score >= 0 && score <= 100 && listOfScores.size() < DEFAULT_MAX_ITEMS)
    return (listOfScores.insert(score) != -1);

  return false;
}

bool ScoreList::remove(ItemType score)
{
  int pos = listOfScores.find(score);
  if (listOfScores.erase(pos))
    return true;
  
  return false;
}

int ScoreList::size() const
{
  return listOfScores.size();
}

ItemType ScoreList::minimum() const
{
  ItemType temp;
  if (!listOfScores.empty())
  {
    listOfScores.get(0, temp);
    return temp;
  }
    
  return NO_SCORE;
}

ItemType ScoreList::maximum() const
{
  ItemType temp;
  if (!listOfScores.empty())
  {
    listOfScores.get(listOfScores.size() - 1, temp);
    return temp;
  }
  
  return NO_SCORE;
}
