/**
 * Program Name: Homework3
 * Written By:   Chungchhay Kuoch
 * Date:         02 11 2017
 */

typedef string dataType;

// File
class File
{
public:
  File(dataType arg)
  {
    strName = arg;
  }
  
  virtual void open(void) const = 0;
  
  dataType name() const
  {
    return strName;
  }
  
  virtual void redisplay(void) const
  {
    cout << "refresh the screen";
  }
  
  virtual ~File(void) { }
  
private:
  dataType strName;
};

// Message has a name
class TextMsg : public File
{
public:
  TextMsg(dataType arg) : File(arg) { }
  
  virtual void open(void) const
  {
    cout << "open text message";
  }
  
  virtual ~TextMsg(void)
  {
    cout << "Destroying " << name() << ", a text message" << endl;
  }
};

// Picture has a name
class Picture : public File
{
public:
  Picture(dataType arg) : File(arg) { }
  
  virtual void open(void) const
  {
    cout << "show picture";
  }
  
  virtual ~Picture(void)
  {
    cout << "Destroying the picture" << name() << endl;
  }
};

// Video has a name and time
class Video : public File
{
public:
  Video(dataType arg, int mn) : File(arg)
  {
    minutes = mn;
  }
  
  virtual void open(void) const
  {
    cout << "play " << minutes << " second video";
  }
  
  virtual void redisplay(void) const
  {
    cout << "replay video";
  }
  
  virtual ~Video()
  {
    cout << "Destroying " << name() << ", a video" << endl;
  }
  
private:
  int minutes;
};

void openAndRedisplay(const File* f)
{
  cout << f->name() << ": ";
  f->open();
  cout << endl << "Redisplay: ";
  f->redisplay();
  cout << endl;
}