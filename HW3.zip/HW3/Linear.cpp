/*
 * Program Name: Homework3 Part2
 * Written By:   Chungchhay Kuoch
 * Date:         2017/2/11
 */

bool somePredicate(double x)
{
  return x > 0;
}

// return true if all elements are true
bool allTrue(const double a[], int n)
{
  if (n <= 0)
    return false;
  
  if (n == 1)
  {
    if (somePredicate(a[0]))
      return true;
    
    return false;
  }
  
  if (somePredicate(a[0]) == false)
    return false;
  
  return allTrue(a + 1, n - 1);
}

// count how many false in the array
int countFalse(const double a[], int n)
{
  if (n <= 0)
    return 0;
  
  if (somePredicate(a[0]) == false)
    return 1 + countFalse(a + 1, n - 1);
  
  return countFalse(a + 1, n -1);
}

// return the first element that is false
int firstFalse(const double a[], int n)
{
  if (n <= 0)
    return -1;
  
  if (somePredicate(a[0]) == false)
      return 0;
  if (firstFalse(a + 1, n - 1) == -1)
    return -1;
  
  return 1 + firstFalse(a + 1, n - 1);
}

// return index of smallest double
int indexOfMin(const double a[], int n)
{
  int min;
  if (n <= 0)
    return -1;
  
  if (n == 1)
    return 0;
  else
  {
    min = indexOfMin(a + 1, n - 1) + 1;
    if (a[0] <= a[min])
      return 0;
  }
  
  return min;
}

// return true if a2 includes in a1
bool includes(const double a1[], int n1, const double a2[], int n2)
{
  if (n2 <= 0)
    return true;
  
  if (n1 < n2 || n1 < 0)
    return false;
  
  if (n1 == 1)
  {
    if (a1[0] == a2[0])
      return true;
  }
  
  if (a1[0] == a2[0])
    return includes(a1 + 1, n1 - 1, a2 + 1, n2 - 1);
  else
    return includes(a1 + 1, n1 - 1, a2, n2);
}